# Next.js Production Docker Deployment

Production-ready, hardened Docker Compose setup for Next.js with PostgreSQL, Redis, and Caddy automatic SSL reverse proxy.

## Prerequisites
1. In your `next.config.js`, ensure standalone output is enabled:
   ```javascript
   module.exports = {
     output: 'standalone',
   };
   ```
2. Place this `Dockerfile` in the root of your Next.js project.

## Quick Start
```bash
# Start Next.js, Postgres, Redis, and Caddy with automatic SSL
docker compose -f docker-compose.nextjs.yml up -d --build
```
