#!/bin/bash
# ==============================================================================
# DEVOPSFORGE PREMIUM BACKUP SCRIPT
# Automates PostgreSQL database dumps, compresses them, uploads them to AWS S3 /
# Cloudflare R2, and sends execution webhook notifications to Slack or Discord.
# ==============================================================================

# 1. Load Environment Settings from .env file
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
else
    echo "Error: .env configuration file not found in current directory!"
    exit 1
fi

# Set backup parameters
BACKUP_DIR="./backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILENAME="db_dump_${TIMESTAMP}.sql.gz"
BACKUP_PATH="${BACKUP_DIR}/${BACKUP_FILENAME}"

# Create local backup folder
mkdir -p $BACKUP_DIR

# 2. Execute DB Dump and compress on the fly
echo "Starting PostgreSQL backup database dump..."
if docker compose exec -t database pg_dumpall -U "${POSTGRES_USER}" | gzip > "$BACKUP_PATH"; then
    echo "Database successfully backed up locally: $BACKUP_PATH"
else
    echo "Error: Database dump failed!"
    # Send failure webhook
    if [ ! -z "$WEBHOOK_URL" ]; then
        curl -X POST -H 'Content-type: application/json' \
            --data "{\"content\":\"🔴 **DevOpsForge Alert**: Database backup failed during local export dump on server $(hostname) at $(date).\"}" \
            $WEBHOOK_URL
    fi
    exit 1
fi

# 3. Upload to AWS S3 / R2 Bucket
echo "Uploading backup dump to S3 bucket (${S3_BUCKET_NAME})..."
if aws s3 cp "$BACKUP_PATH" "s3://${S3_BUCKET_NAME}/${BACKUP_FILENAME}"; then
    echo "Backup file uploaded successfully to S3 cloud storage!"
    
    # Send Success Webhook
    if [ ! -z "$WEBHOOK_URL" ]; then
        FILE_SIZE=$(du -h "$BACKUP_PATH" | cut -f1)
        curl -X POST -H 'Content-type: application/json' \
            --data "{\"content\":\"🟢 **DevOpsForge Success**: Daily database backup created and uploaded to S3 successfully!\n- **File:** \`${BACKUP_FILENAME}\`\n- **Size:** \`${FILE_SIZE}\`\n- **Server:** \`$(hostname)\`\"}" \
            $WEBHOOK_URL
    fi
    
    # 4. Clean up local files older than 7 days to conserve disk space
    find $BACKUP_DIR -name "db_dump_*.sql.gz" -type f -mtime +7 -delete
    echo "Local cleanup complete."
else
    echo "Error: Cloud upload to S3 failed!"
    # Send failure webhook
    if [ ! -z "$WEBHOOK_URL" ]; then
        curl -X POST -H 'Content-type: application/json' \
            --data "{\"content\":\"🔴 **DevOpsForge Alert**: Local DB backup succeeded, but cloud upload to S3 bucket **${S3_BUCKET_NAME}** failed!\"}" \
            $WEBHOOK_URL
    fi
    exit 1
fi

exit 0
