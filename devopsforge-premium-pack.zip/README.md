# DevOpsForge Premium Production Starter Pack
This is the complete template structure to deploy a secure, monitored, and automated multi-container application stack in production.

## What's Included:
1. **`docker-compose.prod.yml`** - Production Compose configuration with automatic SSL/HTTPS, Redis caching, PostgreSQL database replication volumes, and auto-updating container agents.
2. **`Dockerfile.frontend` & `Dockerfile.backend`** - Optimized, multi-stage production Dockerfiles with security-focused non-root users.
3. **`nginx.secure.conf`** - Nginx reverse-proxy setup preloaded with HTTP/2, DDoS rate limiting, Gzip compression, and security headers.
4. **`backup-s3.sh`** - Shell script that automates PostgreSQL backups, compresses them, uploads them to AWS S3/Cloudflare R2, and sends Discord/Slack notification webhooks.

---

## Setup & Deployment Guide

### Prerequisites
*   A VPS running Linux (Ubuntu 20.04/22.04 recommended).
*   Docker & Docker Compose installed.
*   A domain name pointing to your VPS IP address.

### Step 1: Clone and Configure Environment Variables
Create a `.env` file in the root directory:
```env
# Domain Config
DOMAIN_NAME=yourdomain.com
EMAIL_ADDRESS=admin@yourdomain.com

# Database Secrets
POSTGRES_USER=admin_db_user
POSTGRES_PASSWORD=your_highly_secure_db_password
POSTGRES_DB=prod_database

# S3 Backup Settings (For backup-s3.sh)
S3_BUCKET_NAME=your-backups-bucket
AWS_ACCESS_KEY_ID=your_aws_key
AWS_SECRET_ACCESS_KEY=your_aws_secret
AWS_DEFAULT_REGION=us-east-1

# Slack/Discord Alert Webhook (Optional)
WEBHOOK_URL=https://discord.com/api/webhooks/xxxx
```

### Step 2: Deploy
Spin up the entire production environment in detached mode:
```bash
docker compose -f docker-compose.prod.yml up -d --build
```

### Step 3: Set Up Automated Backups
Make the backup script executable and add it to your system crontab:
```bash
chmod +x scripts/backup-s3.sh
# Open crontab manager
crontab -e
# Add the following line to run backups every night at 2:00 AM:
0 2 * * * /bin/bash /path/to/project/scripts/backup-s3.sh
```

---
*DevOpsForge Premium Templates © 2026. Code licensed under MIT.*
