# DevOpsForge Premium Production Starter Pack
This is the complete template structure to deploy a secure, monitored, and automated multi-container application stack in production.

## What's Included:
1. **`docker-compose.prod.yml`** - Production Compose configuration with automatic SSL/HTTPS, Redis caching, PostgreSQL/MySQL database replication volumes, resource limits, and auto-updating container agents.
2. **Framework-Specific Multi-Stage Dockerfiles & Compose Stacks**:
   * **Node.js**: Optimized Alpine build with non-root user.
   * **Laravel (PHP)**: Composer vendor caching, PHP 8.2 CLI, MySQL, and storage permission isolation.
   * **Django (Python)**: Wheel dependency caching, Gunicorn WSGI server, and Postgres.
   * **Spring Boot (Java)**: Multi-stage Maven packaging and hardened JRE runner.
3. **`Caddyfile` / `nginx.secure.conf`** - Production reverse-proxy setups preloaded with HTTP/2 & HTTP/3, auto Let's Encrypt certificates, DDoS rate limiting, Gzip compression, and security headers (HSTS, CSP, X-Frame).
4. **`backup-s3.sh`** - Shell script that automates database dumps, gzip compression, cloud uploads (AWS S3 or Cloudflare R2), and sends Discord/Slack notification webhooks.
5. **`.github/workflows/deploy.yml`** - Automated zero-downtime CI/CD deployment pipeline. Automatically tests Compose syntax and deploys to your VPS via SSH on every push to `main`.

---

## Setup & Deployment Guide

### Prerequisites
*   A VPS running Linux (Ubuntu 22.04 LTS recommended).
*   Docker & Docker Compose installed on your VPS.
*   A domain name with an A record pointing to your VPS IP address.

### Step 1: Clone and Configure Environment Variables
Create a `.env` file in your root project directory:
```env
# Domain Config
DOMAIN_NAME=yourdomain.com
EMAIL_ADDRESS=admin@yourdomain.com

# Database Secrets
POSTGRES_USER=admin_db_user
POSTGRES_PASSWORD=your_highly_secure_db_password
POSTGRES_DB=prod_database

# S3 / Cloudflare R2 Backup Settings (For backup-s3.sh)
S3_BUCKET_NAME=your-backups-bucket
AWS_ACCESS_KEY_ID=your_aws_key
AWS_SECRET_ACCESS_KEY=your_aws_secret
AWS_DEFAULT_REGION=us-east-1

# Slack or Discord Alert Webhook (Optional)
WEBHOOK_URL=https://discord.com/api/webhooks/xxxx
```

### Step 2: Deploy Manually
Spin up the entire production stack in detached mode:
```bash
docker compose -f docker-compose.prod.yml up -d --build
```

### Step 3: Automated Nightly Cloud Backups
Make the backup script executable and configure cron on your VPS:
```bash
chmod +x backup-s3.sh
# Open crontab manager
crontab -e
# Add the following line to run backups every night at 2:00 AM:
0 2 * * * /bin/bash /path/to/project/backup-s3.sh
```

### Step 4: Enable Automated CI/CD (GitHub Actions)
In your GitHub repository, go to **Settings > Secrets and variables > Actions** and add:
* `VPS_HOST`: Your server IP or domain.
* `VPS_USERNAME`: Your SSH username (e.g. `root` or `ubuntu`).
* `VPS_SSH_KEY`: Your private SSH key.
* `DEPLOY_WEBHOOK_URL`: (Optional) Slack or Discord webhook for deployment notifications.

Every time you push code to `main`, GitHub Actions will automatically pull your latest changes, rebuild updated containers, and restart them with zero downtime!

---
*DevOpsForge Premium Templates © 2026. Code licensed under MIT.*
