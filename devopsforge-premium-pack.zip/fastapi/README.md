# FastAPI Production Docker Deployment

Production-ready, hardened Docker Compose setup for FastAPI with PostgreSQL 16, Redis, multi-worker Uvicorn, and Caddy automatic SSL reverse proxy.

## Quick Start
```bash
# Start FastAPI, PostgreSQL, Redis, and Caddy with automatic SSL
docker compose -f docker-compose.fastapi.yml up -d --build

# View container logs
docker compose -f docker-compose.fastapi.yml logs -f backend

# Verify healthcheck
curl -i http://localhost:8080/healthz
```
