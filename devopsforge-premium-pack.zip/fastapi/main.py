from fastapi import FastAPI, status
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup tasks (connection pools, cache init)
    print("FastAPI application starting up in production...")
    yield
    # Shutdown tasks (close pools)
    print("FastAPI application shutting down gracefully...")

app = FastAPI(
    title="Production FastAPI Service",
    version="1.0.0",
    docs_url="/docs",
    redoc_url=None,
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/healthz", status_code=status.HTTP_200_OK, tags=["Health"])
async def health_check():
    return {"status": "healthy", "service": "fastapi"}

@app.get("/", tags=["Root"])
async def root():
    return {"message": "FastAPI Production Backend is Running"}
